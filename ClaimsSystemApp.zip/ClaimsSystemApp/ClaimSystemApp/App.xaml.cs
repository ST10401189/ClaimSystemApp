﻿using System.Windows;

namespace ClaimsSystemApp
{
    public partial class App : Application
    {
    }
}