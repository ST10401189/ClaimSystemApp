# ClaimSystemApp
WPF application for claims management system
