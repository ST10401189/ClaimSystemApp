﻿using System.Windows;

namespace ClaimsSystemApp
{
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            var mainWindow = new MainWindow();

            if (txtUsername.Text.ToLower().Contains("admin"))
            {
                mainWindow.IsAdmin = true;
            }

            mainWindow.Show();
            this.Close();
        }
    }
}