﻿using System.Collections.Generic;
using System.Windows;

namespace ClaimsSystemApp
{
    public partial class ClaimTrackingWindow : Window
    {
        public class Claim
        {
            public string ClaimId { get; set; }
            public string MonthYear { get; set; }
            public string Module { get; set; }
            public string TotalAmount { get; set; }
            public string Status { get; set; }
        }

        public ClaimTrackingWindow()
        {
            InitializeComponent();
            LoadSampleData();
        }

        private void LoadSampleData()
        {
            var claims = new List<Claim>
            {
                new Claim { ClaimId = "1001", MonthYear = "Jan 2024", Module = "CS101 - Introduction to Programming", TotalAmount = "$1,200.00", Status = "Submitted" },
                new Claim { ClaimId = "1002", MonthYear = "Feb 2024", Module = "CS201 - Data Structures", TotalAmount = "$1,500.00", Status = "Approved by Coordinator" },
                new Claim { ClaimId = "1003", MonthYear = "Mar 2024", Module = "CS301 - Algorithms", TotalAmount = "$1,800.00", Status = "Rejected" }
            };

            dgClaims.ItemsSource = claims;
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            var mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}