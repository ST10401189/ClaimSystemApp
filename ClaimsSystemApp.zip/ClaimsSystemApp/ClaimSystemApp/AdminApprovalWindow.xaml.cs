﻿using System.Collections.Generic;
using System.Windows;

namespace ClaimsSystemApp
{
    public partial class AdminApprovalWindow : Window
    {
        public class PendingClaim
        {
            public string ClaimId { get; set; }
            public string Lecturer { get; set; }
            public string MonthYear { get; set; }
            public string Module { get; set; }
            public string TotalAmount { get; set; }
            public string Status { get; set; }
            public string Details { get; set; }
        }

        public AdminApprovalWindow()
        {
            InitializeComponent();
            LoadPendingClaims();
        }

        private void LoadPendingClaims()
        {
            var claims = new List<PendingClaim>
            {
                new PendingClaim
                {
                    ClaimId = "1004",
                    Lecturer = "Dr. Smith",
                    MonthYear = "Apr 2024",
                    Module = "CS101 - Introduction to Programming",
                    TotalAmount = "$1,200.00",
                    Status = "Pending",
                    Details = "Hours: 24\nRate: $50/hour\nWeeks: 4\nTotal: $1,200.00"
                },
                new PendingClaim
                {
                    ClaimId = "1005",
                    Lecturer = "Prof. Johnson",
                    MonthYear = "Apr 2024",
                    Module = "CS201 - Data Structures",
                    TotalAmount = "$1,500.00",
                    Status = "Pending",
                    Details = "Hours: 30\nRate: $50/hour\nWeeks: 4\nTotal: $1,500.00"
                }
            };

            dgPendingClaims.ItemsSource = claims;
        }

        private void DgPendingClaims_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (dgPendingClaims.SelectedItem is PendingClaim selectedClaim)
            {
                txtDetails.Text = selectedClaim.Details;
            }
        }

        private void BtnViewDocument_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Document viewer would open here.");
        }

        private void BtnApprove_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Claim approved successfully!");
        }

        private void BtnReject_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Claim rejected.");
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            var mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}