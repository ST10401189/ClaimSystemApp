﻿using System.Windows;

namespace ClaimsSystemApp
{
    public partial class MainWindow : Window
    {
        public bool IsAdmin { get; set; } = false;

        public MainWindow()
        {
            InitializeComponent();
            CheckAdminRole();
        }

        private void CheckAdminRole()
        {
            btnApproveClaims.Visibility = IsAdmin ? Visibility.Visible : Visibility.Collapsed;
        }

        private void BtnSubmitClaim_Click(object sender, RoutedEventArgs e)
        {
            var submitWindow = new ClaimSubmissionWindow();
            submitWindow.Show();
            this.Hide();
        }

        private void BtnTrackClaims_Click(object sender, RoutedEventArgs e)
        {
            var trackWindow = new ClaimTrackingWindow();
            trackWindow.Show();
            this.Hide();
        }

        private void BtnApproveClaims_Click(object sender, RoutedEventArgs e)
        {
            var approveWindow = new AdminApprovalWindow();
            approveWindow.Show();
            this.Hide();
        }
    }
}