﻿using System.Windows;

namespace ClaimsSystemApp
{
    public partial class ClaimSubmissionWindow : Window
    {
        public ClaimSubmissionWindow()
        {
            InitializeComponent();
            dpMonthYear.SelectedDate = System.DateTime.Now;
        }

        private void BtnUploadDocument_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Document upload functionality would be implemented here.");
        }

        private void BtnCalculate_Click(object sender, RoutedEventArgs e)
        {
            if (double.TryParse(txtHours.Text, out double hours))
            {
                double total = hours * 50;
                txtTotalAmount.Text = total.ToString("F2");
            }
            else
            {
                MessageBox.Show("Please enter valid hours.");
            }
        }

        private void BtnSubmitClaim_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Claim submitted successfully!");
            var mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}